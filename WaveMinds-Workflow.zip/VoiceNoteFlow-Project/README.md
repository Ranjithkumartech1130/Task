# VoiceNoteFlow 🎙️

VoiceNoteFlow is a web application that turns chaotic voice notes and rambling text into structured summaries and actionable to-do lists using Google's Gemini AI.

**Live Demo:** [https://voicenoteflow-project-2.onrender.com/](https://voicenoteflow-project-2.onrender.com/)

## Features
- **Smart Summaries**: AI-generated executive summaries.
- **Action Items**: Automatically extracts a "To-Do List" from your notes.
- **Audio Support**: Upload MP3/WAV files for direct processing.
- **Modern UI**: Clean, responsive design.

## Prerequisites
- [Node.js](https://nodejs.org/) installed on your machine.
- A Google Gemini API Key.

## Setup

1.  **Install Dependencies**:
    ```bash
    npm install
    ```

2.  **Configure Environment**:
    - Create a file named `.env` in the root directory.
    - Add your API key:
      ```
      GROQ_API_KEY=your_actual_api_key_here
      ```

## Running the Project

1.  **Start the Server**:
    Run the following command in your terminal:
    ```bash
    node server.js
    ```
    You should see: `Server running on http://localhost:3000`

2.  **Open the App**:
    Open your browser and visit:
    [http://localhost:3000](http://localhost:3000)

## Usage
1.  **Text Mode**: Type or paste text into the input box and click "Process with AI".
2.  **Audio Mode**: Click "Upload Audio", select an audio file (max 10MB), and click "Process with AI".

## Deployment on Render

This project is configured to be easily deployed on [Render](https://render.com/).

1.  **Push to GitHub**: Ensure your code is pushed to a GitHub repository.
2.  **Create Web Service**: Go to Render, click "New", and select "Web Service". Connect your GitHub repository.
3.  **Configure Settings**:
    *   **Root Directory**: `backend` (Important: We are deploying the backend which serves the frontend).
    *   **Build Command**: `npm install`
    *   **Start Command**: `node server.js`
4.  **Environment Variables**:
    *   Add `GROQ_API_KEY` with your actual API key in the "Environment" tab.
