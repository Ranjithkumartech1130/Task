
const https = require('https');

const key = "AIzaSyDVEqRQG4Ii1r5UBYET9LH4IHIFZHfuPzU";
const model = "gemini-2.0-flash-exp";

const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;

console.log(`Testing ${model}...`);

const req = https.request(url, { method: 'POST', headers: { 'Content-Type': 'application/json' } }, (res) => {
    console.log(`Status: ${res.statusCode}`);
    let data = '';
    res.on('data', c => data += c);
    res.on('end', () => {
        if (res.statusCode === 200) {
            console.log("Success!");
            // console.log(data);
        } else {
            console.log("Error body:", data.substring(0, 200));
        }
    });
});

req.write(JSON.stringify({ contents: [{ parts: [{ text: "Hello" }] }] }));
req.end();
