
const fs = require('fs');
const https = require('https');

const key = "AIzaSyDVEqRQG4Ii1r5UBYET9LH4IHIFZHfuPzU";
const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${key}`;

https.get(url, (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
        fs.writeFileSync('models.json', data);
        console.log("Done");
    });
});
