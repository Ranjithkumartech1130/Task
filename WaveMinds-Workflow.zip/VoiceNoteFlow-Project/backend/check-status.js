
const https = require('https');

const key = "AIzaSyDVEqRQG4Ii1r5UBYET9LH4IHIFZHfuPzU";
const models = ["gemini-1.5-flash", "gemini-pro"];

models.forEach(model => {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
    const req = https.request(url, { method: 'POST', headers: { 'Content-Type': 'application/json' } }, (res) => {
        console.log(`${model}: ${res.statusCode}`);
        res.on('data', () => { }); // Consume
    });
    req.write(JSON.stringify({ contents: [{ parts: [{ text: "hi" }] }] }));
    req.end();
});
