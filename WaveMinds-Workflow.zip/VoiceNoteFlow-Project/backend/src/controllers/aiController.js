const Groq = require("groq-sdk");
const fs = require("fs");
const path = require("path");
const os = require("os");

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

exports.processNote = async (req, res) => {
    try {
        const { note } = req.body;
        const file = req.file;

        if (!note && !file) {
            return res.status(400).json({ error: { message: "Note content or audio file is required." } });
        }

        let fullText = note || "";

        // --- STEP 1: Audio Transcription (If file exists) ---
        if (file) {
            // Determine extension based on mimetype
            let ext = ".mp3";
            if (file.mimetype.includes("wav")) ext = ".wav";
            if (file.mimetype.includes("webm")) ext = ".webm";
            if (file.mimetype.includes("mp4")) ext = ".mp4";
            if (file.mimetype.includes("m4a")) ext = ".m4a";

            const tempFilePath = path.join(os.tmpdir(), `upload_${Date.now()}${ext}`);

            try {
                // Write buffer to temp file for Groq SDK
                fs.writeFileSync(tempFilePath, file.buffer);
                console.log(`Processing audio file: ${tempFilePath} (${file.mimetype})`);

                const transcriptionCompletion = await groq.audio.transcriptions.create({
                    file: fs.createReadStream(tempFilePath),
                    model: "whisper-large-v3-turbo",
                    response_format: "json",
                    language: "en",
                    temperature: 0.0,
                });

                fullText = transcriptionCompletion.text;
                console.log("Transcription successful:", fullText.substring(0, 50) + "...");

            } catch (transcribeError) {
                console.error("Groq Transcription Error Details:", JSON.stringify(transcribeError, null, 2));
                return res.status(500).json({
                    error: {
                        message: "Failed to transcribe audio.",
                        details: transcribeError.message,
                        type: transcribeError.constructor.name
                    }
                });

            } finally {
                // Cleanup temp file
                if (fs.existsSync(tempFilePath)) {
                    fs.unlinkSync(tempFilePath);
                }
            }
        }

        // --- STEP 2: Text Summarization (Always) ---
        if (!fullText || fullText.trim().length === 0) {
            return res.status(400).json({ error: { message: "No text found to summarize." } });
        }

        const chatCompletion = await groq.chat.completions.create({
            messages: [
                {
                    role: "system",
                    content: "You are a helpful assistant. Please summarize the following voice note transcript and extract a clear 'To-Do List' from it. Format the output with Markdown. Use **Summary** and **To-Do List** as headers."
                },
                {
                    role: "user",
                    content: fullText
                }
            ],
            model: "llama-3.3-70b-versatile",
            temperature: 0.5,
            max_tokens: 1024,
        });

        const aiResponse = chatCompletion.choices[0]?.message?.content || "";

        // Return in same structure as before to keep frontend happy
        res.json({
            candidates: [{
                content: {
                    parts: [{ text: aiResponse }]
                }
            }]
        });

    } catch (error) {
        console.error("Server/Groq Error:", error);
        res.status(500).json({ error: { message: "Internal Server Error", details: error.message } });
    }
};
