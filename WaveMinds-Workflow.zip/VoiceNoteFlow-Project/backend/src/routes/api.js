const express = require('express');
const router = express.Router();
const multer = require('multer');
const aiController = require('../controllers/aiController');

// Multer setup for memory storage (files kept in RAM for quick processing)
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

router.post('/process-note', upload.single('audio'), aiController.processNote);

module.exports = router;
