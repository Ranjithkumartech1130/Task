
require('dotenv').config();
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

async function probeModels() {
    const apiKey = "AIzaSyDVEqRQG4Ii1r5UBYET9LH4IHIFZHfuPzU";
    const candidates = [
        "gemini-1.5-flash",
        "gemini-1.5-flash-latest",
        "gemini-1.0-pro",
        "gemini-pro"
    ];

    console.log("Starting Probe...");

    for (const model of candidates) {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
        try {
            const response = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: "Hi" }] }]
                })
            });

            console.log(`Model: ${model} -> Status: ${response.status} ${response.statusText}`);

            if (response.ok) {
                const data = await response.json();
                console.log(`SUCCESS with ${model}`);
                return;
            } else {
                const err = await response.text(); // Get error body
                console.log(`Error Body: ${err.substring(0, 100)}...`);
            }
        } catch (e) {
            console.log(`Model: ${model} -> Exception: ${e.message}`);
        }
    }
    console.log("Probe Complete.");
}

probeModels();
